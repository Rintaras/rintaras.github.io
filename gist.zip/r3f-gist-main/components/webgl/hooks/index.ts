export { useWebGLDetection } from './useWebGLDetection';
